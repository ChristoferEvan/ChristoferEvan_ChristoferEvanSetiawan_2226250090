package com.example.aplikasigithub

class DetailUser {
}